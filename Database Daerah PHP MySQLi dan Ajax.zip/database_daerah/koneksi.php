<?php 

$koneksi = mysqli_connect('localhost','root','root','tutorial_daerah');
?>